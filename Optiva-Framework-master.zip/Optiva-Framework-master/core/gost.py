#! /usr/bin/env python2.7
# core the Optivaframework  
import time
import datetime
from termcolor import colored, cprint

def GostBanner():
    cprint("\033[91m[ \033[92mOptiva-Framework (Web application Scanner) \033[91m]", 'red')
    time.sleep(0.1)
    cprint("        [\033[92mC0d3n4m3 : \033[91mJoker-Security \033[92m]", 'red') 
    time.sleep(0.5)
    print("           \033[91mModules available : \033[92m15")
    print "\n"
    print(" \033[92mFor command type '\033[91mhelp'")
