#! /usr/bin/env python2.7
# core the Optivaframework  
import time
import datetime
from termcolor import colored, cprint


def Gostauto():
	print("\033[92mVersion: " + colored("\033[91m1.0.4"))
	print("\033[92mCoder: " + colored("\033[91mJoker-Security"))
	print("\033[92mModules available: " + colored("\033[91m15"))
	print("\033[92mGithub: " + colored("\033[91mhttps://github.com/joker25000"))
	print("\033[92mtwitter: " + colored("\033[91mhttps://twitter.com/SecurityJoker"))
	print("\033[92mYoutube: " + colored("\033[91mhttps://www.youtube.com/c/Professionalhacker25"))
	print("\033[92mfacebook: " + colored("\033[91mhttps://facebook.com/kali.linux.pentesting.tutorials"))

